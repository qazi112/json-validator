# Contributing Guide

Thank you for considering contributing to this project!

- Use issues for bugs or suggestions
- Clone/Fork the repo, create a feature branch, submit a PR
- Keep changes modular and documented
