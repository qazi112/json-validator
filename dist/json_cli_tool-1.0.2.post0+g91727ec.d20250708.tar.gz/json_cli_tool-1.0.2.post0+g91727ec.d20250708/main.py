from json_validator_cli.cli import main

# Delegate the cli main entry point to main.py
if __name__ == '__main__':
    main()
